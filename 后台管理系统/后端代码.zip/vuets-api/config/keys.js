module.exports = {
  mongoURI:
    'mongodb://vuets:test1234@ds231537.mlab.com:31537/vuets-api',
  secretOrKey: 'secret'
};
