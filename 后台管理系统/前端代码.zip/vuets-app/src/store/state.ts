const state: any = {
  user: null,
  routers: []
};

export default state;
